import React from 'react';
import './headlines.css';

const Headlines = () => (
  <div className="dmr0__section02 section__padding">
    <div className="dmr0__section02-content">
      <p>Dentec MRO Was formed by consolidating interest and requirements, our African Clients ie, Governments, Private and Individuals owners. We then brought them under one roof in order to have full control of delivering our promise which is customer experience.</p>
      <p>This strategy and objective have assisted us to have a clear objective that measures our own deliverables to our clients in the African Continent.</p>
    </div>
  </div>
);

export default Headlines;
