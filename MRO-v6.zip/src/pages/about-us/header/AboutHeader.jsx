import React from 'react';
import ai from '../../../assets/ai.png';
import './about-header.css';

const AboutHeader = () => (
  <div className="dmr0__about_header section__padding" id="home">
    <div className="dmr0__about_header-content">
      <h1 className="gradient__text">About Us</h1>
      <p>Dentec MRO is an Approved FAA Part 145 Component repair and overhaul repair station company based in South Africa at Wonderboom Airport in Pretoria.</p>
    </div>

    <div className="dmr0__about_header-image">
      <img src={ai} />
    </div>
  </div>
);

export default AboutHeader;
