import React from 'react';
import Headlines from './section-01/Headlines';
import AboutHeader from './header/AboutHeader';
import { Blog, Possibility, Features } from '../../containers';
import { CTA, Brand } from '../../components';

import '../../App.css';

const AboutUs = () => (
  <div className="App">
    <div className="gradient__bg">
      <AboutHeader />
    </div>
    <Headlines />
    <Features />
    <Possibility />
    <Brand />
    <CTA />
    <Blog />
  </div>
);

export default AboutUs;
