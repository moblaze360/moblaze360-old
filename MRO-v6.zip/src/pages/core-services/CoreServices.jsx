import React from 'react';
import Headlines from './section-01/Headlines';
import ServicesHeader from './header/ServicesHeader';
import { Blog, Possibility, Features } from '../../containers';
import { CTA, Brand } from '../../components';

const CoreServices = () => (
  <div className="App">
    <div className="gradient__bg">
      <ServicesHeader />
    </div>
    <Headlines />
    <Features />
    <Possibility />
    <Brand />
    <CTA />
    <Blog />
  </div>
);

export default CoreServices;
