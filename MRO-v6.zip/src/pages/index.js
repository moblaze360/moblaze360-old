export { default as Home } from './home/Home';
export { default as AboutUs } from './about-us/AboutUs';
export { default as CoreServices } from './core-services/CoreServices';
export { default as ContactUs } from './contact-us/ContactUs';
