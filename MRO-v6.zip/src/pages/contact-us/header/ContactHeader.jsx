import React from 'react';
import ai from '../../../assets/ai.png';
import './contact-header.css';

const ContactHeader = () => (
  <div className="dmr0__contact_header section__padding" id="home">
    <div className="dmr0__contact_header-content">
      <h1 className="gradient__text">Contact Us</h1>
      <p>We love hearing from our customers, and value your questions and feedback</p>
    </div>

    <div className="dmr0__contact_header-image">
      <img src={ai} />
    </div>
  </div>
);

export default ContactHeader;
