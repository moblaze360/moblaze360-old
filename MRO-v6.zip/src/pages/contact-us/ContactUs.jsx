import React from 'react';
import OurLocation from './section-01/OurLocation';
import ContactHeader from './header/ContactHeader';
import Map from './section-02/Map';

const ContactUs = () => (
  <div className="App">
    <div className="gradient__bg">
      <ContactHeader />
    </div>
    <OurLocation />
    <Map />
  </div>
);

export default ContactUs;
