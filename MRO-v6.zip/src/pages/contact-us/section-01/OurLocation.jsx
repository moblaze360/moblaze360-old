import React from 'react';
import './ourlocation.css';

const OurLocation = () => (
  <>
    <div className="dmr0__ourlocation section__padding">
      <div className="dmr0__ourlocation-content">
        <p>We love hearing from our customers, and value your questions and feedback</p>
      </div>
    </div>
    <div className="dmr0__ourlocation section__padding">
      <div className="dmr0__ourlocation-content">
        <p>Phone/Fax  EMail<br />Office Hrs (T) : +27 12 567 7312/3<br />Email: info@dentecmro.com<br />Fax:  +27 12 567 7320</p>
      </div>
      <div className="dmr0__ourlocation-content">
        <p>Dentec MRO Physical Address<br />Building T213<br />Wonderboom Airport<br />South Africa<br />0017</p>
      </div>
    </div>
  </>
);

export default OurLocation;
