import React from 'react';
import './headlines.css';

const Headlines = () => (
  <div className="dmr0__headlines section__padding">
    <div className="dmr0__headlines-content">
      <p>Dentec-MRO is a B-BBEE Level 2 compliant and black-owned managed company that originated from South Africa. In that&apos; we support our company&lsquo;s National Development Objectives and goals.</p>
      <p>Dentec MRO Allows our customers to claim 125% of their spending towards their preferential procurement. We believe that the Broad-Based Black Economic Empowerment code of good practice (B-BBEE) seeks to accelerate and fast track the re-entry of the previously marginalized communities into the mainstream of the economy.</p>
    </div>
  </div>
);

export default Headlines;
