import React, { useState } from 'react';
import { RiMenu3Line, RiCloseLine, RiMailUnreadFill, RiHome8Fill } from 'react-icons/ri';
import { Link } from 'react-router-dom';
import logo from '../../assets/Dentec-MRO-Logo.png';
import './navbar.css';

const Navbar = () => {
  const [toggleMenu, setToggleMenu] = useState(false);

  return (
    <div className="dmr0__navbar">
      <div className="dmr0__navbar-links">
        <div className="dmr0__navbar-links_logo">
          <img src={logo} />
        </div>
        <div className="dmr0__navbar-links_container">
          <p><a href="/"><div className="contact-span"><div className="iconiq"><RiHome8Fill size="16px" /></div><div>Home</div></div></a></p>
          <p><a href="/about-us">About Us</a></p>
          <p><a href="/core-services">Core Services</a></p>
          <p><a href="#possibility">Quality and Safety</a></p>
          <p><a href="#features">Quality policy</a></p>
        </div>
      </div>
      <div className="dmr0__navbar-sign">
        <Link to="/contact-us">
          <button type="button"><div className="contact-span"><div className="iconiq"><RiMailUnreadFill /></div><div>Contact Us</div> </div></button>
        </Link>
      </div>
      <div className="dmr0__navbar-menu">
        {toggleMenu
          ? <RiCloseLine color="#2D3591" size={27} onClick={() => setToggleMenu(false)} />
          : <RiMenu3Line color="#2D3591" size={27} onClick={() => setToggleMenu(true)} />}
        {toggleMenu && (
        <div className="dmr0__navbar-menu_container scale-up-center">
          <div className="dmr0__navbar-menu_container-links">
            <p><a href="/">Home</a></p>
            <p><a href="/about-us">About Us</a></p>
            <p><a href="/core-services">Core Services</a></p>
            <p><a href="#possibility">Quality and Safety</a></p>
            <p><a href="#features">Quality policy</a></p>
          </div>
          <div className="dmr0__navbar-menu_container-links-sign">
            <Link to="/contact-us">
              <button type="button"><div className="contact-span"><div className="iconiq"><RiMailUnreadFill /></div><div>Contact Us</div> </div></button>
            </Link>
          </div>
        </div>
        )}
      </div>
    </div>
  );
};

export default Navbar;
