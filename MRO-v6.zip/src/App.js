import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Navbar from './components/navbar/Navbar';
import { Footer } from './containers';
import { Home, AboutUs, CoreServices, ContactUs } from './pages';

function App() {
  return (
    <>
      <Router>
        <div className="gradient__bg">
          <Navbar />
        </div>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/about-us" component={AboutUs} />
          <Route path="/core-services" component={CoreServices} />
          <Route path="/contact-us" component={ContactUs} />
        </Switch>
        <Footer />
      </Router>
    </>
  );
}

export default App;
