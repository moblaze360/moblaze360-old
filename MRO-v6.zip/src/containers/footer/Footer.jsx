import React from 'react';
import dmr0Logo from '../../logo.svg';
import './footer.css';

const Footer = () => (
  <div className="dmr0__footer section__padding">
    <div className="dmr0__footer-links">
      <div className="dmr0__footer-links_logo">
        <img src={dmr0Logo} alt="dmr0_logo" />
      </div>
      <div className="dmr0__footer-links_div">
        <h4>Company</h4>
        <p>About Us</p>
        <p>Our Services</p>
        <p>Quality and Safety</p>
        <p>Quality Policy</p>
        <p>Contact Us</p>
      </div>
      <div className="dmr0__footer-links_div">
        <h4>Get in touch</h4>
        <p>info@dentecmro.com</p>
        <p>Office: +27 12 567 7312/3</p>
        <p>Fax:  +27 12 567 7320</p>
        <br />
        <p>Building T213</p>
        <p>Wonderboom Airport</p>
        <p>South Africa</p>
        <p>0017</p>
      </div>
    </div>

    <div className="dmr0__footer-copyright">
      <p>dentecmro.com © 2022 - All rights reserved</p>
    </div>
  </div>
);

export default Footer;
