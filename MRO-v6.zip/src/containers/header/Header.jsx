import React from 'react';
import ai from '../../assets/ai.png';
import './header.css';

const Header = () => (
  <div className="dmr0__header section__padding" id="home">
    <div className="dmr0__header-content">
      <h1 className="gradient__text">Aerospace Solutions</h1>
      <p>FDR and CVR transcription for many Aircraft types using mordern software.</p>
    </div>

    <div className="dmr0__header-image">
      <img src={ai} />
    </div>
  </div>
);

export default Header;
